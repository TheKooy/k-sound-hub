K-Sound Hub wallpaper pack

Files:
- ksound_hub_wallpaper_original_1536x1024.png: original generated image (1536x1024)
- ksound_hub_wallpaper_4k_cropped_3840x2160.png: upscaled and center-cropped to true 4K (3840x2160)
- ksound_hub_wallpaper_4k_blurfill_3840x2160.png: true 4K (3840x2160) with blurred background fill to preserve the original framing

Notes:
- The generated source image was not originally 4K.
- The 4K files in this pack were prepared from that source image.
- For an app background with a dark overlay + blur, the blurfill version is often the safest.
